package minesdvg;
import minesdvg.controlador.Controlador;

/**
 * Clase principal del joc
 */
public class Mines {
    /**
     * Funcio principal del joc
     * @param args  arguments que rebra la funcio
     * @author DAVID VAQUERA GARCIA
     */
    public static void main(String[] args) throws Exception {

        // inicia el joc
        Controlador.jugar();
    }
}
