package minesdvg;
import minesdvg.controlador.Controlador;

/**
 * Clase principal del joc
 */
public class Mines {
    /**
     * funció main del joc
     * @param args  arguments que rebrá la funcio
     */
    public static void main(String[] args) {
        /**
         * crida la funció jugar de la clase Controlador per inicialitzar el joc
         */
        Controlador.jugar();
    }
}
