package minesdvg.vista;

public class Vista {
    public static void monstrarCampDeMines(char [][] tauler){
        int tamanyFil = tauler.length, tamanyCol = tauler[0].length;

        System.out.printf("\t%s", " ");
        for (int i = 1; i < tamanyCol - 1; i++){
            System.out.printf("\t%d", i);
        }
        System.out.println();
        for (int i = 1; i < tamanyFil - 1; i++){
            System.out.printf("\t%c", (char)(i + 'A')-1);
           for (int j = 1; j < tamanyCol - 1; j++){
                System.out.printf("\t%c", tauler[i][j]);
            }
            System.out.println();
        }
    }
    public static void mostrarMisatge(String msg){
        System.out.println(msg);
    }
}
