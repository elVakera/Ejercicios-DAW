package minesdvg.controlador;
import minesdvg.model.Model;
import minesdvg.vista.Vista;

import java.util.Scanner;

/**
 * Clase principal del joc encarregada de controlar les accions del jugador
 */
public class Controlador {
    /**
     * @scn variable global de tipus Scanner per detectar les accions del jugador
     */
    public static Scanner scn = new Scanner(System.in);
    public static void jugar(){
        /**
         * variables locals
         * @files numero de files del tauler
         * @columnes numero de columnes del tauler
         * @bombes numero de bombes al tauler
         */
        int files = 8, columnes = 8, bombes = 10;

        //mostrar misatge inicial
        Vista.mostrarMisatge("S'ha generat un tauler de " + files + " files X " + columnes + " columnes amb "+ bombes + " bombes");
        Model.inicialitzarJoc(files,columnes,bombes);
    }
}
