package minesdvg.model;
import minesdvg.vista.Vista;

public class Model {
    //variables constants globals privades
    private static int FILES, COLUMNES, BOMBES;

    // variables globals privades
    private static boolean jocFinalitzat;
    private static char[][] campDeMinesOcult, campDeMinesVisible;

    //Metodes Publics

    /**
     * inicialitzarJoc inicilitza el joc amb els parametres seguents
     *
     * @param f numero de files
     * @param c numero de columnes
     * @param b numero de bombes
     */
    public static void inicialitzarJoc(int f, int c, int b) {
        FILES = f + 2;
        COLUMNES = c + 2;
        BOMBES = b;
        char visible = '·', ocult = ' ';
        campDeMinesOcult = new char[FILES][COLUMNES];
        campDeMinesVisible = new char[FILES][COLUMNES];

        inicialitzarCampDeMines(campDeMinesOcult, ocult);
        inicialitzarCampDeMines(campDeMinesVisible, visible);
        posarBombesAleatoriament(campDeMinesOcult);
        comptarQuantesBombes(campDeMinesOcult);
        Vista.mostrarMisatge("\nCamp Ocult");
        Vista.monstrarCampDeMines(campDeMinesOcult);
        Vista.mostrarMisatge("\nCamp Visible");
        Vista.monstrarCampDeMines(campDeMinesVisible);

    }
    //Metodes Privats

    /**
     *
     */
    private static void inicialitzarCampDeMines(char [][] tauler, char caracter) {
        int tamanyFil = tauler.length, tamanyCol = tauler[0].length;

        for (int i = 0; i < tamanyFil; i++){
            for (int j = 0; j < tamanyCol; j++){
                tauler[i][j] = caracter;
            }
        }
    }

    /**
     *
     */
    public static void posarBombesAleatoriament(char [][] taulerO) {
        int tamanyFil = taulerO.length, tamanyCol = taulerO[0].length;
        int posiI, posiJ;

        for(int i = 0; i < BOMBES; i++){
            posiI = (int)(Math.random() * ((tamanyFil - 1) - 1) + 1);
            posiJ = (int)(Math.random() * ((tamanyCol - 1) - 1) + 1);

            if(taulerO[posiI][posiJ] != 'B'){
                taulerO[posiI][posiJ] = 'B';
            }else {
                i--;
            }
        }
    }
    /**
     *
     */
    public static void comptarQuantesBombes(char[][] taulerO) {
        int tamanyFil = taulerO.length, tamanyCol = taulerO[0].length;

        for (int i = 1; i < tamanyFil - 1; i++){
            for (int j = 1; j < tamanyCol - 1; j++){
                int detectaBombes = 0;

                if(taulerO[i][j] != 'B') {
                    if (taulerO[i - 1][j - 1] == 'B') {
                        detectaBombes++;
                    }
                    if (taulerO[i - 1][j] == 'B') {
                        detectaBombes++;
                    }
                    if (taulerO[i - 1][j + 1] == 'B') {
                        detectaBombes++;
                    }
                    if (taulerO[i][j - 1] == 'B') {
                        detectaBombes++;
                    }
                    if (taulerO[i][j + 1] == 'B') {
                        detectaBombes++;
                    }
                    if (taulerO[i + 1][j - 1] == 'B') {
                        detectaBombes++;
                    }
                    if (taulerO[i + 1][j] == 'B') {
                        detectaBombes++;
                    }
                    if (taulerO[i + 1][j + 1] == 'B') {
                        detectaBombes++;
                    }
                    taulerO[i][j] = (char) (detectaBombes + '0');
                }
            }
        }
    }
}
